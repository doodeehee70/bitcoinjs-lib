import * as input from './input';
import * as output from './output';

export { input, output };
