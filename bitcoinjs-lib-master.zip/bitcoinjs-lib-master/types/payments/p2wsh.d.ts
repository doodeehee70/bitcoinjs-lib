import { Payment, PaymentOpts } from './index';
export declare function p2wsh(a: Payment, opts?: PaymentOpts): Payment;
