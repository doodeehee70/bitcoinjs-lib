/// <reference types="node" />
import { Stack } from '../../payments';
export declare function check(script: Buffer | Stack): boolean;
export declare namespace check {
    var toJSON: () => string;
}
